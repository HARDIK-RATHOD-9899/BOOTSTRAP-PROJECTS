$(document).ready(function () {
    $(".fa-bars").click(function () {
        $("nav").toggle(1000);
    });
});

